# Backend de um projeto pessoal de controle financeiro
  Esse projeto está razoavelmente organizado apenas para que eu conseguisse 
  me localizar e rastrear erros de forma eficiente pois preciso finaliza-lo
  o quanto antes.

  Em suma, esse projeto utiliza um banco de dados sqlite3 pela sua praticidade 
  de ser um banco de dados em arquivo, dessa forma utilizo G-drive para o acessar
  de diferentes máquinas (deveras coveniente para um universitário como eu).

  Para fazer a comunicação com o banco, utilizei o modulo sqlite3 do próprio python
  e decidi utilizar um padrão de projeto semelhante ao utilizado na criação de APIs 
  em alguns frameworks (models e controllers).

# Backend of a personal financial management project
This project is reasonably organized just so that I could locate myself and track errors efficiently as I need to finish it as soon as possible.

In summary, this project uses a sqlite3 database for its convenience of being a file-based database, thus I use G-Drive to access it from different machines (quite convenient for a university student like me).

To communicate with the database, I used Python's built-in sqlite3 module and decided to use a design pattern similar to the one used in creating APIs in some frameworks (models and controllers).


  
